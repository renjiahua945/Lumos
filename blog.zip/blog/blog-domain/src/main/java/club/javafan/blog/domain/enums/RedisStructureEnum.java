package club.javafan.blog.domain.enums;
/**
 * @author 不会敲代码的小白(博客)
 * @date 2019/12/10 22:56
 * @desc redis 的数据结构枚举
 */
public enum RedisStructureEnum {
    LIST,STRING,SET,HASH,ZSET
}
